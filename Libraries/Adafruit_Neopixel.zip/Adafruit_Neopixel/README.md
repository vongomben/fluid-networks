# DEPRECATED LIBRARY  [![Build Status](https://travis-ci.com/Seeed-Studio/Seeed_LED_Ring.svg?branch=master)](https://travis-ci.com/Seeed-Studio/Seeed_LED_Ring)

This library has been deprecated! We are leaving this up for historical and research purposes but archiving the repository.

We are now only supporting the use of our [Seeed_Learning_Space](https://github.com/Seeed-Studio/Seeed_Learning_Space/tree/master/Seeed_Led_Ring)

# SEEED LED Ring
This library is for SEEED LED ring.




## NOTICE
Due to the current limitation, the brightness of the LED is limited in the program.If you insist on adjusting the brightness limit, you can modify the setBrightness() function.  
But this may cause the light to not work properly.


